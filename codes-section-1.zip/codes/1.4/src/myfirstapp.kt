
fun main(args: Array<String>) {

    // This is my first app ... Cool !
    println("Hello World")      // This is another comment !
    println("Kotlin is Great")

    println("80 / 10")
}
