package com.google.kotlin.section3

fun main(args: Array<String>) {

    printDimension(breadth = 10, length = 30)
}

fun printDimension(length: Int, breadth: Int) {

    println("The length is $length")
    println("The breadth is $breadth")
}
